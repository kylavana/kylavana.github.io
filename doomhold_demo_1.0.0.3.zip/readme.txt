<<<<<<<<<<<<>>>>>>>>>>>>>
DOOMHOLD � demo v.1.0.0.3
<<<<<<<<<<<<>>>>>>>>>>>>>

Thanks for downloading the DOOMHOLD demo!  Roughly the first-third of the full game is playable in this demo.  The full version will feature two more bosses, as well as more monsters, items, spells, and rooms to explore.

Note: This demo does not allow the player to save game data.  The save feature will be accessible in the full version. 

TOC:
1. System requirements
2. Installation
3. How to play
	3.1. Your goal
	3.2. Controls
	3.3. Getting started
	3.4. HUD
	3.5. Inventory
	3.6. Ability scores
	3.7. Player death
4. Items
	4.1. Item types
	4.2. Prefixes/suffixes
5. Spells
6. Monsters
7. Updates/fixes
8. Credits
9. Legal stuff

======================
1. System requirements
======================

OS: Windows 7 or later

================
2. Installation 
================

This demo doesn�t require any installation!  Just double-click the .exe file to launch the game.

================
3. How to play
================

3.1. Your Goal
--------------
In DOOMHOLD, you ultimate goal is to reach the bottom of the castle and defeat the NECROMANCER.  In order to do so, you must first recover three wardstones that will allow you to pass the magical wards that block certain areas of the castle.  Additionally, you will not be able to face the NECROMANCER until you defeat his two guardians and take their orbs. 

The castle is guarded by many minions of the NECROMANCER, and you�ll have to defeat them in order to gather experience and items to increase your power.  


3.2. Controls
-------------

[arrow keys] � move player/move cursor (if inventory is open)

[spacebar] � open/close inventory

[ctrl] � drop item (if inventory is open)

[Z] � use equipped item in Z slot/equip item to Z slot (if inventory is open)

[X] � use equipped item in X slot/equip item to X slot (if inventory is open)

[f4] � toggle fullscreen mode

Double tap [left arrow] or [right arrow] � dash (player will move more quickly, but drains stamina)

Hold and release [Z] or [X] � performs a �power attack� with your equipped weapon.  A power attack with a sword will swing it in a wide arc around you.  A power attack with a bow will fire an arrow that penetrates multiple enemies.  Additionally, Power attacks do double damage but consume stamina.  You cannot perform a power attack with a spell.  

[esc] � exit game (you can also exit the game by opening the menu, moving the cursor over the �exit� option at the top of the screen, and pressing either [Z] or [X].


3.3. Getting started
--------------------
You can start a new game by pressing [enter] on the menu screen while the �New game� option is highlighted. 

When you start a new game, a short introduction will play.  You can skip this introduction at any time by pressing any key.

After the introduction, your character will be in the center of a long hall.  You�ll also notice that there are three items (short sword, short bow, book of firebolt) in front of you.  You can pick up items simply by walking over them.  You can equip items by opening your inventory [spacebar], and then pressing [Z] or [X] while your cursor is over an item.

To use an equipped item, exit your inventory [spacebar] and then press the key that item is equipped to.  For example, if you have a sword equipped to your Z slot, pressing [Z] will attack with the sword.  If you have a book of firebolt equipped to your X slot, pressing [X] will cast the firebolt spell. 

Equip-able items include: swords, bows, spell books, bombs, and shields.
Potions can be used by pressing either the [Z] or [X] key while your cursor is over them in the inventory screen.  They cannot be equipped.

You can exit the game to windows at any point by hitting [esc].  Please be aware that you will lose all of your progress!

3.4. The HUD
------------
At the top of the screen, you will find the HUD.  

At the left, you will find displays of your current Hit points(hp), magic points(mp), and stamina points(sp).  If you are hit by an enemy or a projectile, you will lose hit points.  Magic points are used every time you cast a spell.  Stamina points are used when you dash or use a power attack.  Magic and stamina will regenerate over time (magic regenerates at a much slower rate).

At the right, you will find your Z and X slots.  These slots will show what items (if any) are equipped to them.  See section 3.3. for more details about equipping items. 

3.5. The inventory
------------------
Your inventory can be opened at any time by pressing [spacebar].  Opening the inventory will pause the action in the room you�re currently in.  You can close the inventory by pressing [spacebar] again.

The inventory will show you a map of the castle, what items you currently have, what quest items you have found, how much gold you have, and your current ability scores.

When you move your cursor over an item, a short description of it will appear in the box near the bottom of the screen.

Additionally, near the top of the screen you will find three options; exit, load, and save.  The load and save options are disabled in the demo.  You can use the exit option by moving your cursor over it, and pressing [Z] or [X].  This will exit the game to windows, your progress will not be saved. 

3.6. Ability scores
-------------------
Your character has three ability scores: Might(mt), Agility(ag), and intellect(in).  Might governs how many hit points you have, agility governs how much stamina you have, while intellect determines how many magic points you have.  Additionally, might adds damage to sword attacks, agility increase the power of your bow attacks, while intellect will increase your spell damage.  

To raise an ability score, you have to defeat monsters.  The ability score that increases depends on the weapon you used to kill the monster.  As you kill monsters with a sword, your might will increase.  Defeat enemies with a bow to increase agility, and raise your intellect by killing monsters with spells. 

Weapons and spell books have a minimum ability score requirement that must be met before you can equip them.  If you do not meet the ability requirement for a weapon, it�s description will be red when you move the cursor over it. 

3.7. Player death
-----------------
Your character is killed when you run out of hit points.  You will respawn in the first room of the castle, but you will lose half of the gold you had prior to death.  Upon respawning your HP, MP, and SP will be refilled. 

========
4. Items
========
 
4.1. Item types
---------------
As you explore DOOMHOLD, you will find the following types of items:
swords, bows, spell books, potions, bombs, and shields.

Swords generally do more damage than bows, but you must get close to an enemy.  There are three kinds of swords: short swords(s.sword), long swords(l.sword), and warblades.

Bows do less damage than swords on average, but allow you to engage enemies from a distance.  There are three kinds of bows: short bows(s.bow), long bows(l.bow) and runebows.

Spells have various effects depending on the type, they are discussed more in depth in section 5.

Potions come in three varieties: Health(red), Magic(blue), Stamina(yellow). Using a potion will recover some points of the type it is related to.  See section 3.3. for more information about using potions.

Bombs can be placed to destroy cracked wall sections (as well as reveal completely hidden passages).  You place a bomb, equip it to your Z or X slot, close your inventory and then use it by pressing either [Z] or [X] (depending upon what slot it is equipped to). The bomb will start flashing, and you will have a few moments to get out of the way before it explodes.  Bombs can also damage enemies. 

Shields can be equipped and used like other weapons, but they don�t damage enemies.  Instead, shields will block enemy attacks, and certain projectiles from hitting you.  There are three types of shields:
Bronze(brz)- Blocks melee attacks and mundane projectiles (arrows, spears, etc.)
Steel(stl)- Blocks melee attacks, mundance projectiles, and magical projectiles.
Mithril(mth)- Blocks melee attacks and mundane projectiles, reflects magical projectiles.


4.2. Weapon Prefixes/suffixes
-----------------------------
All swords and bows have a prefix, and may also be granted with a suffix that adds a special effect.
Additionally, shields may have certain suffixes (specified by a �*�)

Prefixes
********
Rusty: -1 damage
Iron: normal damage
Steel: +1 damage

Suffixes
********
Of the bear: +1 might*
Of the Wolf: +1 agility*
Of the owl: +1 intellect*
Of the Bat: 1 magic point stolen on hit
Of the vampire: 1 health point stolen on hit
Of the stars: +1 all attributes*
Of fire: 25% chance to create explosion on hit
Of ice: 25% chance to freeze enemy on hit
Of thunder: 25% chance to fire lightning on hit

=========
5. Spells
=========

Firebolt: A bolt of fire that damages a single enemy.

Icebolt: A bolt of ice that damages and freezes a single enemy.

Lightning: A powerful bolt of lightning that damages multiple enemies in a row.

Fireball: A bolt of fire flies forth and explodes powerfully on impact dealing damage to all enemies within range.

Frost ray: A short ray of frost shoots forward, freezing and damaging all enemies it hits.

Heal: Replenishes some of your Hit points.

Shield: Creates a bubble of magic force around you that blocks incoming projectiles and prevents enemies from reaching you.

Storm: A powerful beam of magical energy that does massive damage to enemies.

===========
6. Monsters
===========

Skeleton Warriors- The most common enemy, they attack with swords.  As you progress further into the castle you face stronger varieties.

Bats/Ravens- These creatures are relatively weak, but they move quickly and will unexpectedly swoop down on you.

Skeleton Mages- The enemies will throw spells at you.  The ice variety will freeze you with their attacks.

Knights- These powerful enemies have a lot of hit points but move slowly.  They are immune to normal bow attacks.  The stronger varieties are also immune to some spells.  The attack with swords at close range, but have a quick lunging attack that can take you off-guard.

Goblins- Goblins are cowardly creatures that attack at range by throwing spears.  If you get too close, they will run from you. 

Succubi- Demonesses that attack with flaming whips.  They are immue to fire-based attacks. 

================
7. Updates/fixes
================

1.0.0.2 release
---------------
Sword base damage increased
Improved hit detection with sword 
Player attack is no longer interrupted when hit
Improved hit decetion with shield
Added succubus enemy
Added tip at start of game to open inventory
Added tips in inventory: equip/use item/drop item

1.0.0.3 release
---------------
Rebalanced spell damage/cost
some monsters walk around when idle now
added new font
added notification for level ups
fixed some issues with game intro
rebalanced encounters in first few rooms
added label for map
esc no longer exits the game

==========
8. Credits
==========

DOOMHOLD was created with Game Maker 1.4

Design, programming, and art by Kyla Vana

Open-source music courtesy of:
Poinl
SketchyLogic
www.megupets.com

Special thanks to:
www.opengameart.org 

==============
9. Legal stuff
==============

DOOMHOLD is copyrighted to Kyla Vana.

The application may not be duplicated, modified, or distributed without consent of the owner.

Please contact Kyla Vana at kyla.extra@gmail.com with any questions.
